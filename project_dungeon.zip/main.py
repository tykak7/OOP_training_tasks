from dungeon import Dungeon
import subprocess
import os

if __name__ == "__main__":
    load_file = input("Enter the name of the saved file (leave empty for a new game): ")
    if load_file:
        if os.path.exists(load_file):
            dungeon = Dungeon.load_from_file(load_file)
            hero_name = dungeon.hero.name
        else:
            print("Specified file not found. Starting a new game.")
            hero_name = input("What is your name hero? ")
            dungeon = Dungeon(size=(50, 20), tunnel_number=40, hero_name=hero_name)
    else:
        hero_name = input("What is your name hero? ")
        dungeon = Dungeon(size=(50, 20), tunnel_number=40, hero_name=hero_name)
    while True:
        subprocess.Popen("cls", shell=True).communicate()
        print(dungeon)
        print(dungeon.message)
        action = input(f"Select an action {hero_name}: (L)EFT, (R)IGHT, (D)OWN, (U)P, (A)TTACK, (Q)UIT, (SA)VE: ")
        if action == "Q":
            print("You coward!")
            exit(0)
        else:
            dungeon.hero_action(action)
        if dungeon.hero.hp < 1:
            print(dungeon.message)
            exit(0)
        # save_file = input("Enter the name of the file to save the game (leave empty to skip saving): ")
        if action == "SA":
            dungeon.save_to_file(hero_name)

