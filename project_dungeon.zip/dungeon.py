from abstract_classes import AbstractDungeon
from copy import deepcopy
from datetime import datetime
from map_entities import Hero, Goblin
import random
import pickle

class Dungeon(AbstractDungeon):
    def __init__(self, size: tuple, tunnel_number: int, hero_name: str):
        super().__init__(size)
        self.hero = Hero("@", hero_name, [1, 1], 5, 5, 1)
        self.tunnel_number = tunnel_number
        self.start_row = 1
        self.start_col = 1
        self.max_tunnels = tunnel_number
        self.starting_entities = ["goblin", "goblin", "goblin", "goblin", "goblin", "goblin", "goblin", "goblin", "goblin", "goblin", "goblin", "goblin"]
        self.entities = []
        self.empty_space = []
        self.message = ""
        self.create_dungeon()

    def __str__(self):
        printable_map = ""
        for row in self.current_map:
            for column in row:
                printable_map += column
            printable_map += "\n"
        return printable_map

    def create_dungeon(self):
        width = self.size[1]
        height = self.size[0]

        # Number of rows and columns must be greater than 3
        if width <= 3 or height <= 3:
            raise ValueError("Number of rows and columns must be greater than 3.")

        # Generation of an empty dungeon
        dungeon = [['▓' for _ in range(width)] for _ in range(height)]

        # Initial position
        start_row, start_col = 1, 1
        dungeon[start_row][start_col] = '.'

        # Tunnels generation
        for _ in range(self.max_tunnels):
            # Random direction of tunnel generation
            direction_row, direction_col = random.choice([(0, 1), (0, -1), (1, 0), (-1, 0)])

            # Up
            if (direction_row, direction_col) == (-1, 0) and start_row > 1:
                tunnel_length = random.randint(1, start_row - 1)
                for ind in range(tunnel_length):
                    dungeon[start_row - ind][start_col] = "."
                start_row -= tunnel_length
                self.max_tunnels -= 1
            # Down
            elif (direction_row, direction_col) == (1, 0) and start_row < height - 2:
                tunnel_length = random.randint(1, height - start_row - 2)
                for ind in range(tunnel_length):
                    dungeon[start_row + ind][start_col] = "."
                start_row += tunnel_length
                self.max_tunnels -= 1
            # Left
            elif (direction_row, direction_col) == (0, -1) and start_col > 1:
                tunnel_length = random.randint(1, start_col - 1)
                for ind in range(tunnel_length):
                    dungeon[start_row][start_col - ind] = "."
                start_col -= tunnel_length
                self.max_tunnels -= 1
            # Right
            elif (direction_row, direction_col) == (0, 1) and start_col < width - 2:
                tunnel_length = random.randint(1, width - start_col - 2)
                for ind in range(tunnel_length):
                    dungeon[start_row][start_col + ind] = "."
                start_col += tunnel_length
                self.max_tunnels -= 1

        self.dungeon_map = dungeon
        self.find_empty_space()
        self.place_entities(self.starting_entities)
        self.current_map = deepcopy(self.dungeon_map)
        self.empty_space = list(set(self.empty_space))
        self.current_map[self.hero.position[0]][self.hero.position[1]] = self.hero.map_identifier

    def find_empty_space(self):
        self.empty_space = []
        for row in range(1, self.size[0] - 1):
            for col in range(1, self.size[1] - 1):
                if self.dungeon_map[row][col] == ".":
                    self.empty_space.append((row, col))


    def hero_action(self, action):
        if action == "R":
            if self.hero.position[1] + 1 < self.size[1] - 1:
                if self.dungeon_map[self.hero.position[0]][self.hero.position[1] + 1] != "▓":
                    self.hero.position[1] += 1
        elif action == "L":
            if self.hero.position[1] - 1 > 0:
                if self.dungeon_map[self.hero.position[0]][self.hero.position[1] - 1] != "▓":
                    self.hero.position[1] -= 1
        elif action == "U":
            if self.hero.position[0] - 1 > 0:
                if self.dungeon_map[self.hero.position[0] - 1][self.hero.position[1]] != "▓":
                    self.hero.position[0] -= 1
        elif action == "D":
            if self.hero.position[0] + 1 < self.size[0] - 1:
                if self.dungeon_map[self.hero.position[0] + 1][self.hero.position[1]] != "▓":
                    self.hero.position[0] += 1
        elif action == "A":
            fighting = False
            for entity in self.entities:
                if tuple(self.hero.position) == entity.position:
                    if hasattr(entity, "attack"):
                        self.fight(entity)
                        fighting = True
            if not fighting:
                self.message ="Your big sword is hitting air really hard!"

        self.update_map(self.entities)

        if self.hero.hp < 1:
            self.message += "\nTHIS IS THE END"

    def place_entities(self, entities: list):
        position = random.sample(self.empty_space, len(entities))
        for idx, entity in enumerate(self.starting_entities):
            if entity == "goblin":
                self.entities.append(Goblin(identifier="\033[38;5;1mg\033[0;0m",
                                            position=position[idx], base_attack=-1,
                                            base_ac=0, damage=1))
        for entity in self.entities:
            self.dungeon_map[entity.position[0]][entity.position[1]] = entity.map_identifier

    def update_map(self, entities: list):
        self.current_map = deepcopy(self.dungeon_map)
        self.current_map[self.hero.position[0]][self.hero.position[1]] = self.hero.map_identifier

    def fight(self, monster):
        hero_roll = self.hero.attack()
        monster_roll = monster.attack()
        if hero_roll["attack_roll"] > monster.base_ac:
            monster.hp -= hero_roll["inflicted_damage"]
            if monster.hp > 0:
                self.message = f"Hero inflicted {hero_roll['inflicted_damage']}"
            else:
                self.message = f"Hero Hero inflicted {hero_roll['inflicted_damage']} damage and slain {monster}"
                self.hero.gold += monster.gold
                self.hero.xp += 1
                self.dungeon_map[monster.position[0]][monster.position[1]] = "."
                self.entities.remove(monster)
        if monster_roll["attack_roll"] > self.hero.base_ac:
            self.message += f"\nMonster inflicted {monster_roll['inflicted_damage']} damage"
            self.hero.hp -= monster_roll['inflicted_damage']
            if self.hero.hp < 1:
                self.message += f"{self.hero.name} have been slained by {monster}"
        self.message += f"\nHero HP: {self.hero.hp}  Monster HP: {monster.hp}"

    def save_to_file(self, file_name):
        current_datetime = datetime.now()
        timestamp = str(current_datetime.strftime("%Y-%m-%d %H-%M-%S"))
        file_name = f"{file_name}_{timestamp}.dng"
        with open(file_name, "wb") as file:
            pickle.dump(self, file)

    @staticmethod
    def load_from_file(file_name):
        with open(file_name, "rb") as file:
            dungeon = pickle.load(file)

        return dungeon

